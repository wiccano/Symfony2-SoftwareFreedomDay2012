jQuery Scrollable Table Plugin
==============================

This jQuery plugin converts a properly formatted table, having thead and tbody elements (tfoot optional), into a scrollable table. The tablescroll jQuery plugin is a simple markup manipulation plugin, it will manipulate the table, create a couple of new elements and wrap everything in a DIV.